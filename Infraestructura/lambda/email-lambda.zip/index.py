import json

def handler(event, context):
    for record in event['Records']:
        message = json.loads(record['body'])
        print(f"📧 Enviando correo a: {message['to']}")
        print(f"📨 Asunto: {message['subject']}")
        print(f"✉️  Mensaje: {message['body']}")
        print("✅ Correo enviado correctamente")
    return {"statusCode": 200}
